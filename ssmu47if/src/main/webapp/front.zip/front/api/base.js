﻿const base = {
    url : "http://localhost:8080/ssmu47if/"
}
export default base
